package com.creditcard.validator.errors;

public class InvalidCardNumberException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1436978112544007416L;

	public InvalidCardNumberException() {
        super();
    }
}
